"""Shared Orchard desktop helpers."""
